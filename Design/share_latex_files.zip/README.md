# Heis prosjekt-working progress
------------------------------
- 12.02.2017:	Innlevering av design decumentasjon
- ??.??.2017	Innlevering av 		

Creately.com: use case diagram, klassediagram, kommunikasjonsdiagram

sekvensdiagrammer ferdig: stopp + utvidelse,   ankommer etasje,  velg retning/bestill heis
